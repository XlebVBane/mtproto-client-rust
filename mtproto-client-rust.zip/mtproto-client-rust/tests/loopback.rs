// ============================================================
// Интеграционный тест: реальный TCP-loopback.
// Клиентская сторона — MtProxyCodec через Framed; серверная сторона —
// симулятор MTProxy-сервера (те же ключи, что выводит настоящий прокси).
// ============================================================

use bytes::Bytes;
use mtproto_client_rust::{MtProxyCodec, MtProxySecret};
use tokio::net::{TcpListener, TcpStream};
use tokio_util::codec::Framed;
use tokio_stream::StreamExt as _;
use futures_util::SinkExt as _;

use aes::cipher::{KeyIvInit as _, StreamCipher as _};
use sha2::{Digest as _, Sha256};

type Ctr = ctr::Ctr128BE<aes::Aes256>;

/// Серверная сторона: принимает сокет, восстанавливает init из хендшейка
/// (первые 56 байт открыты), декодирует клиентские кадры, отвечает одним.
async fn proxy_sim(stream: TcpStream, secret: [u8; 16], reply_payload: &[u8]) {
    use tokio::io::AsyncReadExt as _;

    let mut sock = stream;

    // --- хендшейк: 64 байта, из них первые 56 — открытый init ---
    let mut handshake = [0u8; 64];
    sock.read_exact(&mut handshake).await.unwrap();
    let init_head: [u8; 56] = handshake[0..56].try_into().unwrap();

    // ключ клиента = sha256(init[8:40] ++ secret), iv = init[40:56]
    let mut hasher = Sha256::new();
    hasher.update(&init_head[8..40]);
    hasher.update(&secret);
    let mut client_cipher: Ctr = Ctr::new(hasher.finalize().as_slice().try_into().unwrap(), init_head[40..56].try_into().unwrap());

    // Клиент шифровал ВСЕ 64 байта init одним блоком: в проводе первые 56
    // байт лежат открыто, а хвост 56..64 зашифрован keystream-позициями
    // 56..64. Прокручиваем первые 56 байт keystream, потом расшифровываем хвост.
    let mut init = [0u8; 64];
    init[..56].copy_from_slice(&init_head);
    let mut probe = [0u8; 56];
    client_cipher.apply_keystream(&mut probe);
    let tail = &mut handshake[56..];
    client_cipher.apply_keystream(tail);
    init[56..].copy_from_slice(tail);

    // серверная сторона шифрует клиенту rx-ключом (reverse(init[8:56]))
    let mut reversed = [0u8; 48];
    for i in 0..48 {
        reversed[i] = init[55 - i];
    }
    let mut hasher = Sha256::new();
    hasher.update(&reversed[0..32]);
    hasher.update(&secret);
    let mut server_cipher: Ctr = Ctr::new(hasher.finalize().as_slice().try_into().unwrap(), reversed[32..48].try_into().unwrap());

    // --- читаем первый клиентский кадр (TCP может дробить его) ---
    let mut buf = [0u8; 4096];
    let mut wire: Vec<u8> = Vec::new();
    let declared = loop {
        let n = sock.read(&mut buf).await.unwrap();
        if n == 0 {
            panic!("EOF до получения полного кадра");
        }
        // расшифровываем по мере прихода — keystream непрерывный
        let seg = &mut buf[..n];
        client_cipher.apply_keystream(seg);
        wire.extend_from_slice(seg);
        if wire.len() >= 4 {
            let d = i32::from_le_bytes(wire[0..4].try_into().unwrap()) as usize;
            if wire.len() >= d {
                break d;
            }
        }
    };
    assert!(declared >= 4);
    let got = &wire[4..4 + declared - (declared % 4)];
    assert_eq!(got, &[1u8, 2, 3, 4]); // payload из теста

    // --- отвечаем: длина + payload, шифруем ---
    let mut out = Vec::new();
    out.extend_from_slice(&(reply_payload.len() as i32).to_le_bytes());
    out.extend_from_slice(reply_payload);
    server_cipher.apply_keystream(&mut out);
    use tokio::io::AsyncWriteExt as _;
    sock.write_all(&out).await.unwrap();
}

#[tokio::test]
async fn full_stream_over_loopback() {
    let secret = MtProxySecret::parse("0123456789abcdef0123456789abcdef").unwrap();
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();

    let reply = vec![9u8; 32];
    let sim = tokio::spawn({
        let reply = reply.clone();
        let secret = secret.clone();
        async move {
            let (sock, _) = listener.accept().await.unwrap();
            proxy_sim(sock, *secret.as_bytes(), &reply).await;
        }
    });

    let tcp = TcpStream::connect(addr).await.unwrap();
    let mut framed = Framed::new(tcp, MtProxyCodec::new(&secret, 2));

    // клиент шлёт кадр (init уйдёт вместе с ним)
    framed.send(Bytes::from_static(&[1, 2, 3, 4])).await.unwrap();

    // серверный ответ приходит уже расшифрованным
    let got = tokio::time::timeout(std::time::Duration::from_secs(5), framed.next())
        .await
        .unwrap()
        .unwrap()
        .unwrap();
    assert_eq!(&got[..], &reply[..]);

    sim.await.unwrap();
}
