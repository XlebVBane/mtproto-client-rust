//! Пример: транспорт MTProto-прокси в терминах grammers.
//!
//! Запуск: `cargo run --example grammers_client --features grammers -- <proxy-secret>`
//!
//! grammers (Rust-порт Telethon) общается с MTProto через трейт
//! `grammers_mtproto::transport::Transport`. Этот крейт даёт реализацию
//! `MtProxyTransport` — точный аналог ConnectionTcpMTProxyRandomizedIntermediate.
//!
//! ВАЖНО: `grammers-mtsender` при подключении использует адреса датацентров
//! и не знает о прокси — чтобы трафик шёл через MTProto-прокси, нужно
//! подставить адрес прокси в место подключения (небольшой патч mtsender,
//! рабочая реализация: репозиторий «Боярышник БОТ», vendor/grammers-mtsender).
//! Сама обфускация/кадрирование — целиком в этом крейте.

#[cfg(feature = "grammers")]
fn main() -> Result<(), Box<dyn std::error::Error>> {
    use grammers_mtproto::transport::Transport as _;
    use grammers_mtproto::DequeBuffer;
    use mtproto_client_rust::{MtProxySecret, grammers_transport::MtProxyTransport};

    let secret_raw = std::env::args().nth(1).expect("нужен секрет прокси");
    let secret = MtProxySecret::parse(&secret_raw)?;

    // 1. Создаём транспорт (аналог connection=...RandomizedIntermediate в Telethon).
    //    dc_id — датацентр, через который прокси маршрутизирует трафик.
    let mut transport = MtProxyTransport::from_secret(&secret, 2);
    println!(
        "Транспорт создан (формат секрета {:?}, отпечаток {})",
        secret.kind(),
        secret.fingerprint()
    );

    // 2. pack(): первый вызов добавит 64-байтовый handshake + зашифрованный кадр.
    let mut buf = DequeBuffer::with_capacity(8, 0);
    buf.extend_back(&[1, 2, 3, 4]); // payload MTProto кратен 4
    transport.pack(&mut buf);
    let wire = buf.as_ref().to_vec();
    println!(
        "Первый кадр на проводе: {} байт (64 handshake + 4 длина + payload + паддинг)",
        wire.len()
    );
    // Хвост handshake (56..60) — зашифрованный тег dd dd dd dd: открытый тег не светится.
    assert_ne!(&wire[56..60], &[0xdd, 0xdd, 0xdd, 0xdd][..]);

    // 3. Дальше буфер отдаётся в mtsender, который шлёт его в сокет,
    //    подключённый к АДРЕСУ ПРОКСИ (патч mtsender), а входящие байты
    //    расшифровываются через transport.unpack(...).

    if secret.is_fake_tls() {
        println!("⚠️ ee-секрет: нужен FakeTLS-транспорт (в крейте пока только plain/dd).");
    }
    Ok(())
}

#[cfg(not(feature = "grammers"))]
fn main() {
    println!("Соберите с фичей: cargo run --example grammers_client --features grammers -- <secret>");
}
