//! Пример: сырой поток через MTProto-прокси.
//!
//! Запуск: `cargo run --example raw_stream -- 127.0.0.1 443 <secret-hex>`
//!
//! Показывает минимальное использование без MTProto-логики:
//! кодек сам обфусцирует кадры, а вы просто читаете/пишете байты
//! (полезно для своих протоколов поверх прокси или отладки).

use bytes::Bytes;
use futures_util::SinkExt as _;
use mtproto_client_rust::{connect, MtProxySecret};
use tokio_stream::StreamExt as _;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut args = std::env::args().skip(1);
    let host = args.next().unwrap_or_else(|| "127.0.0.1".into());
    let port: u16 = args.next().and_then(|s| s.parse().ok()).unwrap_or(443);
    let secret_raw = args.next().expect("нужен секрет прокси (hex/base64)");

    let secret = MtProxySecret::parse(&secret_raw)?;
    println!(
        "Подключаюсь к {host}:{port} (dc=2, секрет {:?}, отпечаток {})",
        secret.kind(),
        secret.fingerprint()
    );
    if secret.is_fake_tls() {
        println!("⚠️ Секрет ee* требует FakeTLS-транспорта, которого в крейте пока нет — соединение может не установиться.");
    }

    let mut stream = connect(&host, port, &secret, 2).await?;
    println!("TCP установлен. Кодек готов: первый отправленный кадр унесёт с собой handshake.");

    // Пример: отправим «пустой» кадр данных (не валидный MTProto — прокси
    // передаст его датацентру, тот ответит транспортной ошибкой, но мы
    // увидим, что канал жив).
    stream.send(Bytes::from(vec![0u8; 4])).await?;
    println!("Кадр отправлен. Читаю ответ (10 сек)…");

    loop {
        let frame = match tokio::time::timeout(std::time::Duration::from_secs(10), stream.next()).await
        {
            Ok(Some(Ok(frame))) => frame,
            Ok(Some(Err(e))) => {
                println!("Транспорт ответил: {e}");
                break;
            }
            Ok(None) => {
                println!("Соединение закрыто.");
                break;
            }
            Err(_) => {
                println!("Таймаут ожидания ответа.");
                break;
            }
        };
        println!("Получен кадр {} байт: {:02x?}", frame.len(), &frame[..frame.len().min(16)]);
        break;
    }

    Ok(())
}
